package br.com.alura.screenmach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmachApplicationTests {

	@Test
	void contextLoads() {
	}

}
