package br.com.alura.screenmach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScreenmachApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScreenmachApplication.class, args);
	}

}
